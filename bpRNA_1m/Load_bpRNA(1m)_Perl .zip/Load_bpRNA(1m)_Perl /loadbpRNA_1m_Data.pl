#!/usr/bin/perl
use DBI;
use lib ;
use strict;


#####################################################################
# 2018  Padideh Danaee,Michelle Wiley, Mason Rouches, David Hendrix #
# http://hendrixlab.cgrb.oregonstate.edu                            #
#####################################################################

my $usage = "loadbpRNAData.pl <bpRNATable File Name> \n";
my $db = getDatabase();
my $bpRNAFileName = $ARGV[0] or die $usage;


loadMethodTable($db);
loadTypeTabel($db);
loadValidationTable($db);
loadReferenceDatabaseTable($db);


my $pkBulges = loadBulgeTable($db);
my($emptyHairpins,$pkHairpins)=loadHairpinTable($db);
my $pkStems =  loadStemTable($db);
my $multiLoopIDs=loadMultiLoop($db);
my $pkMultiLoops=loadMultiLoopBranch($db,$multiLoopIDs);
my $internalLoopIDs=loadInternalLoop($db);
my $pkInternalLoops=loadInternalLoopBranch($db,$internalLoopIDs);
my ($pkUnpairedRegions_X,$pkUnpairedRegions_E)=loadUnpairedRegionTable($db);
loadPseudoknotTable($db,$pkBulges,$pkHairpins,$pkStems,$pkMultiLoops,$pkInternalLoops,$pkUnpairedRegions_X,$pkUnpairedRegions_E);
loadPKBPs($db);
loadSegmentTable($db);

### LOAD THe MAIN TABLE ###
loadRNATable($db,$bpRNAFileName,$emptyHairpins);

sub getDatabase {
    my($database,$host,$user,$pass) = ("bpRNA","localhost", "PLACE YOUR DATABASE USERNAME HERE", "PLACE YOUR DATABASE PASSWORD HERE");
    my $dsn="DBI:mysql:database=$database;host=$host;"; 
    my $dbh = DBI->connect($dsn,$user,$pass) || die "Unable to connect to MySQL: $DBI::errstr \n";
    my $dbh="";
    return $dbh;
}



#####################
#### LOAD TABLES ####
#####################

### MAIN TABLE:  RNA ###
sub loadRNATable {
    my($db,$bpRNAFileName,$emptyHairpins)=@_;
    open(FL,$bpRNAFileName) or die "Could not open $bpRNAFileName for reading\n";
    while(<FL>){
	chomp;
	unless(/^#/){
	    my $c1 = $db->prepare("INSERT INTO RNA (rna_ID,rna_Name,rna_Desc,rna_Sequence,rna_Length,rna_UnpairedBPs,rna_PairedBPs,rna_NumMolecules,rna_HasPK,rna_HasLigand,rna_HasModifiedResidues,rna_Flag,rna_OriginName,rna_OriginPubMedID,rna_OriginURL,rna_OriginPubMedCentralID,rna_OriginSourceImageURL,rna_PhylogeneticClass,rna_OrganismName,rna_OrganismDesc,rna_CreationDate,reference_ID,type_ID,method_ID,validation_ID,rna_Domain,rna_Lineage) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?, ?, ?,?)");

	    my($rna_ID,$rna_Name,$rna_Desc,$rna_Sequence,$rna_Length,$rna_UnpairedBPs,$rna_PairedBPs,$rna_NumMolecules,$rna_HasPK,$rna_HasLigand,$rna_HasModifiedResidues,$rna_Flag,$rna_OriginName,$rna_OriginPubMedID,$rna_OriginURL,$rna_OriginPubMedCentralID,$rna_OriginSourceImageURL,$rna_PhylogeneticClass,$rna_OrganismName,$rna_OrganismDesc,$rna_CreationDate,$reference_ID,$type_ID,$method_ID,$validation_ID,$rna_Domain,$rna_Lineage)=split/\t/;
            if($emptyHairpins->{$rna_ID}){
                if($rna_Flag==1){
                    $rna_Flag=3;
                }elsif($rna_Flag==0){
                    $rna_Flag=2;
                }
            }

	    $c1->execute($rna_ID,$rna_Name,$rna_Desc,$rna_Sequence,$rna_Length,$rna_UnpairedBPs,$rna_PairedBPs,$rna_NumMolecules,$rna_HasPK,$rna_HasLigand,$rna_HasModifiedResidues,$rna_Flag,$rna_OriginName,$rna_OriginPubMedID,$rna_OriginURL,$rna_OriginPubMedCentralID,$rna_OriginSourceImageURL,$rna_PhylogeneticClass,$rna_OrganismName,$rna_OrganismDesc,$reference_ID,$type_ID,$method_ID,$validation_ID,$rna_Domain,$rna_Lineage);
	}
    }
			  
    close FL;
}


### BULGE ###
sub loadBulgeTable {
    my($db)=@_;
    my %pkBulges;
    my $allBulgesFileName="allBulges.txt";
    open(FL,$allBulgesFileName) or die "Could not open $allBulgesFileName for reading\n";
    while(<FL>){
	chomp;
	unless(/^#/){
	    my($rna_ID,$bulge_SubID,$bulge_Seq,$bulge_StartPos,$bulge_StopPos,$bulge_5pBP,$bulge_5pBPPos1,$bulge_5pBPPos2,$bulge_3pBP,$bulge_3pBPPos1,$bulge_3pBPPos2,$bulge_Length,$isPK)=split/\t/;
	    my $c1 = $db->prepare("INSERT INTO Bulge (bulge_SubID,bulge_Seq,bulge_StartPos,bulge_StopPos,bulge_5pBP,bulge_5pBPPos1,bulge_5pBPPos2,bulge_3pBP,bulge_3pBPPos1,bulge_3pBPPos2,bulge_Length,bulge_isPK,bulge_CreationDate,rna_ID) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,NOW(),?)");
	    $c1->execute($bulge_SubID,$bulge_Seq,$bulge_StartPos,$bulge_StopPos,$bulge_5pBP,$bulge_5pBPPos1,$bulge_5pBPPos2,$bulge_3pBP,$bulge_3pBPPos1,$bulge_3pBPPos2,$bulge_Length,$isPK,$rna_ID);
	    if($isPK==1){
		my $pkID=$rna_ID ."_". $bulge_SubID;
		my $c2 = $db->prepare("select max(bulge_ID) from Bulge");
		$c2->execute();
		my @row = $c2->fetchrow_array();
		$pkBulges{$pkID}=$row[0];
	    }
	}
    }
    close FL;
    return \%pkBulges;
}

### HAIRPIN ###
sub loadHairpinTable {
    my($db)=@_;
    my %emptyHairpins;
    my %pkHairpins;
    my $allHairpinFileName="allHairpins.txt";
    open(FL,$allHairpinFileName) or die "Could not open $allHairpinFileName for reading \n";
    while(<FL>){
	chomp;
	unless(/^#/){
	    my($rna_ID,$hairpinloop_SubID,$hairpinloop_StartPos,$hairpinloop_StopPos,$hairpinloop_Seq,$hairpinloop_Length,$hairpinloop_BP,$hairpinloop_BPPos1,$hairpinloop_BPPos2,$isPK)=split/\t/;
	    my $c1 = $db->prepare("INSERT INTO HairpinLoop (hairpinloop_SubID,hairpinloop_Sequence,hairpinloop_StartPos,hairpinloop_StopPos,hairpinloop_BP,hairpinloop_BPPos1,hairpinloop_BPPos2,hairpinloop_Length,hairpinloop_isPK,hairpinloop_CreationDate,rna_ID) VALUES (?,?,?,?,?,?,?,?,?,NOW(),?)");
	    $c1->execute($hairpinloop_SubID,$hairpinloop_Seq,$hairpinloop_StartPos,$hairpinloop_StopPos,$hairpinloop_BP,$hairpinloop_BPPos1,$hairpinloop_BPPos2,$hairpinloop_Length,$isPK,$rna_ID);
	    if($hairpinloop_Length==0){
		unless($emptyHairpins{$rna_ID}){
		    print "$rna_ID,$hairpinloop_SubID\n";
		    $emptyHairpins{$rna_ID}=1;
		}
	    }
	    if($isPK==1){
                my $pkID=$rna_ID ."_". $hairpinloop_SubID;
		my $c2 = $db->prepare("select max(hairpinloop_ID) from HairpinLoop");
		$c2->execute();
                my @row = $c2->fetchrow_array();
                $pkHairpins{$pkID}=$row[0];
            }
	}
    }
    close FL;
    return (\%emptyHairpins,\%pkHairpins);
}

### MULTILOOP ###
sub loadMultiLoop {
    my($db)=@_;
    my %multiLoopIDs;
    my $multiloopFileName="allMultiLoops.txt";
    open(FL,$multiloopFileName) or die "Could not open $multiloopFileName for reading\n";
    while(<FL>){
	chomp;
	unless(/^#/){
	    my($rna_ID,$multiloop_SubID)=split/\t/;
	    my $c1 = $db->prepare("INSERT INTO MultiLoop (multiloop_SubID,multiLoop_CreationDate,rna_ID)  VALUES (?,NOW(),?)"); 
	    $c1->execute($multiloop_SubID,$rna_ID);
	    my $c2 = $db->prepare("select max(multiloop_ID) from MultiLoop");
	    $c2->execute();
	    my @row = $c2->fetchrow_array();
            my $id=$rna_ID ."_" .$multiloop_SubID;
            $multiLoopIDs{$id}=$row[0];
	}
    }
    close FL;
    return \%multiLoopIDs;

}


### MULTILOOP BRANCHES ###
sub loadMultiLoopBranch {
    my($db,$multiLoopIDs)=@_;
    my %pkMultiLoops;
    my $multiLoopBranchFieName="allMultipLoopBranches.txt";
    open(FL,$multiLoopBranchFieName) or die "Could not open $multiLoopBranchFieName for reaindg \n";
    while(<FL>){
	chomp;
	unless(/^#/){
                 my($rna_ID,$multiLoop_SubID,$multiloopBranch_SubID,$multiloopBranch_StartPos,$multiloopBranch_StopPos,$multiloopBranch_Seq,$multiloopBranch_Length,$multiloopBranch_5pBP,$multiloopBranch_5pBPPos1,$multiloopBranch_5pBPPos2,$multiloopBranch_3pBP,$multiloopBranch_3pBPPos1,$multiloopBranch_3pBPPos2,$multiLoopBranch_isPK)=split/\t/;
                 my $c1 = $db->prepare("INSERT INTO MultiLoopBranch (multiloopBranch_SubID,multiloopBranch_Seq,multiloopBranch_StartPos,multiloopBranch_StopPos,multiloopBranch_Length,multiloopBranch_5pBP,multiloopBranch_5pBPPos1,multiloopBranch_5pBPPos2,multiloopBranch_3pBP,multiloopBranch_3pBPPos1,multiloopBranch_3pBPPos2,multiLoopBranch_isPK,multiLoopBranch_CreationDate,multiloop_ID) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,NOW(),?)");
                 my $id=$rna_ID."_".$multiLoop_SubID;
                 my $multiloop_ID=$multiLoopIDs->{$id};
                 $c1->execute($multiloopBranch_SubID,$multiloopBranch_Seq,$multiloopBranch_StartPos,$multiloopBranch_StopPos,$multiloopBranch_Length,$multiloopBranch_5pBP,$multiloopBranch_5pBPPos1,$multiloopBranch_5pBPPos2,$multiloopBranch_3pBP,$multiloopBranch_3pBPPos1,$multiloopBranch_3pBPPos2,$multiLoopBranch_isPK,$multiloop_ID);

		 if($multiLoopBranch_isPK==1){
                     my $pkID=$rna_ID ."_". $multiloopBranch_SubID;
                     my $c2 = $db->prepare("select max(multiloopBranch_ID) from MultiLoopBranch");
		     $c2->execute();
                     my @row = $c2->fetchrow_array();
                     $pkMultiLoops{$pkID}=$row[0];
                 }
	}
    }
    close FL;
    return \%pkMultiLoops;

}

### INTERNAL LOOP ###
sub loadInternalLoop {
    my($db)=@_;
    my $internalLoopFileName="allInternalLoops.txt";
    my %internalLoopIDs;
    open(FL,$internalLoopFileName) or die "Could not open $internalLoopFileName for reading \n";
    while(<FL>){
	chomp;
	unless(/^#/){
	    my($rna_ID,$internalloop_SubID)=split/\t/;
	    my $c1 = $db->prepare("INSERT INTO InternalLoop (internalloop_SubID,internalloop_CreationDate,rna_ID) VALUES (?,NOW(),?)");
	    $c1->execute($internalloop_SubID,$rna_ID);
	    my $c2 = $db->prepare("select max(internalloop_ID) from InternalLoop");  
	    $c2->execute();          
	    my @row = $c2->fetchrow_array();
	    my $id=$rna_ID."_".$internalloop_SubID;
	    $internalLoopIDs{$id}=$row[0];
	}
    }
    close FL;
    return \%internalLoopIDs;
}

### INTERNAL LOOP BRANCHES ###
sub loadInternalLoopBranch {
    my($db,$internalLoopIDs)=@_;
    my %pkInternalLoops;
    my $internalLoopBranchFieName="allInternalLoopBranches.txt";
    open(FL,$internalLoopBranchFieName) or die "Could not open $internalLoopBranchFieName for reaindg \n";
	 while(<FL>){
	     chomp;
	     unless(/^#/){
		 my($rna_ID,$internalloop_SubID,$internalloopBranch_SubID,$internalloopBranch_Start,$internalloopBranch_Stop,$internalloopBranch_BP,$internalloopBranch_BPPos1,$internalloopBranch_BPPos2,$internalloopBranch_Seq,$internalloopBranch_Length,$isPK)=split/\t/;
		 
		 my $c1 = $db->prepare("INSERT INTO InternalLoopBranch (internalloopBranch_SubID,internalloopBranch_Seq,internalloopBranch_StartPos,internalloopBranch_StopPos,internalloopBranch_BP,internalloopBranch_BPPos1,internalloopBranch_BPPos2,internalloopBranch_Length,internalloopBranch_CreationDate,internalloopBranch_isPK,internalloop_ID) VALUES (?,?,?,?,?,?,?,?,?,NOW(),?)");
		 my $id=$rna_ID."_".$internalloop_SubID;
		 my $internalloop_ID=$internalLoopIDs->{$id};
		 $c1->execute($internalloopBranch_SubID,$internalloopBranch_Seq,$internalloopBranch_Start,$internalloopBranch_Stop,$internalloopBranch_BP,$internalloopBranch_BPPos1,$internalloopBranch_BPPos2,$internalloopBranch_Length,$isPK,$internalloop_ID);

		 if($isPK==1){
		     my $pkID=$rna_ID ."_". $internalloopBranch_SubID;
		     my $c2 = $db->prepare("select max(internalloopBranch_ID) from InternalLoopBranch");
		     $c2->execute();
		     my @row = $c2->fetchrow_array();
		     $pkInternalLoops{$pkID}=$row[0];
		 }
	     }
	 }
    
    close FL;
    return \%pkInternalLoops;
}


### PSEUDOKNOT ###
sub loadPseudoknotTable {
    my($db,$pkBulges,$pkHairpins,$pkStems,$pkMultiLoops,$pkInternalLoops,$pkUnpairedRegions_X,$pkUnpairedRegions_E)=@_;
    my $pseudoknotFileName="allPKs.txt";
    open(FL,$pseudoknotFileName) or die "Could not open $pseudoknotFileName for reading \n";
    while(<FL>){
	chomp;
	unless(/^#/){
	    my($rna_ID,$pseudoknot_SubID,$pseudoknot_NumBPs,$pseudoknot_5pStartPos,$pseudoknot_5pStopPos,$pseudoknot_3pStartPos,$pseudoknot_3pStopPos,$pseudoknot_loopType1,$id1,$pseudoknot_loopType2,$id2)=split/\t/;

	    my $c1 = $db->prepare("INSERT INTO Pseudoknot (pseudoknot_SubID,pseudoknot_NumBPs,pseudoknot_5pStartPos,pseudoknot_5pStopPos,pseudoknot_3pStartPos,pseudoknot_3pStopPos,pseudoknot_loopType1,pseudoknot_ID1,pseudoknot_loopType2,pseudoknot_ID2,pseudoknot_CreationDate,rna_ID) VALUES (?,?,?,?,?,?,?,?,?,?,NOW(),?)");
	    my $pseudoknot_ID1=0;
            my $pseudoknot_ID2=0;
            #Find the loopTypeID                                                                                                                                                               
            if($pseudoknot_loopType1 eq 'B'){
                $pseudoknot_ID1=$pkBulges->{$rna_ID."_".$id1};
            }elsif($pseudoknot_loopType1 eq 'H'){
                $pseudoknot_ID1=$pkHairpins->{$rna_ID."_".$id1};
            }elsif($pseudoknot_loopType1 eq 'S'){
                $pseudoknot_ID1=$pkStems->{$rna_ID."_".$id1};
            }elsif($pseudoknot_loopType1 eq 'I'){
                $pseudoknot_ID1=$pkInternalLoops->{$rna_ID."_".$id1};
            }elsif($pseudoknot_loopType1 eq 'M'){
                $pseudoknot_ID1=$pkMultiLoops->{$rna_ID."_".$id1};
            }elsif($pseudoknot_loopType1 eq 'X'){
		my $pkid=$rna_ID."_".$id1. "_". $pseudoknot_loopType1;
                $pseudoknot_ID1=$pkUnpairedRegions_X->{$pkid};
            }elsif($pseudoknot_loopType1 eq 'E'){
		my $pkid=$rna_ID."_".$id1. "_". $pseudoknot_loopType1;
		$pseudoknot_ID1=$pkUnpairedRegions_E->{$pkid};
	    }

            if($pseudoknot_loopType2 eq 'B'){
                $pseudoknot_ID2=$pkBulges->{$rna_ID."_".$id2};
            }elsif($pseudoknot_loopType2 eq 'H'){
                $pseudoknot_ID2=$pkHairpins->{$rna_ID."_".$id2};
            }elsif($pseudoknot_loopType2 eq 'S'){
                $pseudoknot_ID2=$pkStems->{$rna_ID."_".$id2};
            }elsif($pseudoknot_loopType2 eq 'I'){
                $pseudoknot_ID2=$pkInternalLoops->{$rna_ID."_".$id2};
            }elsif($pseudoknot_loopType2 eq 'M'){
                $pseudoknot_ID2=$pkMultiLoops->{$rna_ID."_".$id2};
            }elsif($pseudoknot_loopType2 eq 'X'){
		my $pkid=$rna_ID."_".$id2. "_". $pseudoknot_loopType2;
                $pseudoknot_ID2=$pkUnpairedRegions_X->{$pkid};
            }elsif($pseudoknot_loopType2 eq 'E'){
		my $pkid=$rna_ID."_".$id2. "_". $pseudoknot_loopType2;
		$pseudoknot_ID2=$pkUnpairedRegions_E->{$pkid};
	    }

	    $c1->execute($pseudoknot_SubID,$pseudoknot_NumBPs,$pseudoknot_5pStartPos,$pseudoknot_5pStopPos,$pseudoknot_3pStartPos,$pseudoknot_3pStopPos,$pseudoknot_loopType1,$pseudoknot_ID1,$pseudoknot_loopType2,$pseudoknot_ID2,$rna_ID)
	}
    }
    close FL;
}


sub loadPKBPs {
    my($db)=@_;
    my $pkBPsFileName="allPKBPs.txt";
    open(FL,$pkBPsFileName) or die "Could not open $pkBPsFileName for reading\n";
    while(<FL>){
        chomp;
        "CREATE TABLE PseudoknotBasePairs(".
             "pseudoknotBPs_ID bigint AUTO_INCREMENT NOT NULL PRIMARY KEY,".
             "pseudoknotBPs_SubID Longtext NULL,".
             "pseudoknotBPs_5pPos int NULL,".
             "pseudoknotBPs_5pNuc varchar(50) NULL,".
             "pseudoknotBPs_3pPos int NULL,".
             "pseudoknotBPs_3pNuc varchar(50) NULL,".
             "pseudoknotBPs_CreationDate DATETIME NULL ,".
             "pseudoknot_ID bigint NOT NULL)";
        unless(/^#/){
            my($rna_ID,$pseudoknot_SubID,$pseudoknotBPs_SubID,$pseudoknotBPs_5pPos,$pseudoknotBPs_5pBase,$pseudoknotBPs_3pPos,$pseudoknotBPs_3pBase)=split/\t/;

            my $c2 = $db->prepare("select pseudoknot_ID  from Pseudoknot where rna_ID=$rna_ID and pseudoknot_SubID='$pseudoknot_SubID'");
            $c2->execute();
            my @row = $c2->fetchrow_array();
            my $pseudoknot_ID=$row[0];

            my $c1 = $db->prepare("INSERT INTO PseudoknotBasePairs (pseudoknotBPs_SubID,pseudoknotBPs_5pPos,pseudoknotBPs_5pNuc,pseudoknotBPs_3pPos,pseudoknotBPs_3pNuc,pseudoknotBPs_CreationDate,pseudoknot_ID) VALUES (?,?,?,?,?,NOW(),?)");
            $c1->execute($pseudoknotBPs_SubID,$pseudoknotBPs_5pPos,$pseudoknotBPs_5pBase,$pseudoknotBPs_3pPos,$pseudoknotBPs_3pBase,$pseudoknot_ID);

        }
    }
    close FL;
}


sub loadUnpairedRegionTable {
    my($db)=@_;
    my %pkUnpairedRegions_E;
    my %pkUnpairedRegions_X;
    my $unpairedRegionFileName="allUnpairedBases.txt";
    open(FL,$unpairedRegionFileName) or die "Could not open $unpairedRegionFileName for reading\n";
    while(<FL>){
	chomp;
	unless(/^#/){
	    my($rna_ID,$unpairedRegion_SubID,$unpairedRegion_Start,$unpairedRegion_Stop,$unpairedRegion_Seq,$unpairedRegion_Length,$unpairedRegion_Type,$unpairedRegion_5pBPPos1,$unpairedRegion_5pBPPos2,$unpairedRegion_5pBP,$unpairedRegion_3pBPPos1,$unpairedRegion_3pBPPos2,$unpairedRegion_3pBP,$unpairedRegion_isPK)=split/\t/;
	    my $c1 = $db->prepare("INSERT INTO UnpairedRegion (unpairedRegion_SubID,unpairedRegion_Start,unpairedRegion_Stop,unpairedRegion_Seq,unpairedRegion_Length,unpairedRegion_5pBP,unpairedRegion_5pBPPos1,unpairedRegion_5pBPPos2,unpairedRegion_3pBP,unpairedRegion_3pBPPos1,unpairedRegion_3pBPPos2,unpairedRegion_Type,unpairedRegion_isPK,unpairedRegion_CreationDate,rna_ID) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,NOW(),?)"); 
	    $c1->execute($unpairedRegion_SubID,$unpairedRegion_Start,$unpairedRegion_Stop,$unpairedRegion_Seq,$unpairedRegion_Length,$unpairedRegion_5pBP,$unpairedRegion_5pBPPos1,$unpairedRegion_5pBPPos2,$unpairedRegion_3pBP,$unpairedRegion_3pBPPos1,$unpairedRegion_3pBPPos2,$unpairedRegion_Type,$unpairedRegion_isPK,$rna_ID);
	    if($unpairedRegion_isPK==1){
		my $pkID=$rna_ID ."_". $unpairedRegion_SubID."_" . $unpairedRegion_Type ;
                my $c2 = $db->prepare("select max(unpairedRegion_ID) from UnpairedRegion");
		$c2->execute();
                my @row = $c2->fetchrow_array();
		if($unpairedRegion_Type eq "X"){
		    $pkUnpairedRegions_X{$pkID}=$row[0];
		}elsif($unpairedRegion_Type eq "E"){
		    $pkUnpairedRegions_E{$pkID}=$row[0];
		}
	    }
	    
	}
    }
    close FL;
    return \%pkUnpairedRegions_X,\%pkUnpairedRegions_E;
}

### STEM ###
sub loadStemTable{
    my($db)=@_;
    my %pkStems;
    my $stemFileName="allStems.txt";
    open(FL,$stemFileName) or die "Could not open $stemFileName for reading\n";
    while(<FL>){
	chomp;
	unless(/^#/){
	    my($rna_ID,$stem_SubID,$stem_5p_StartPos,$stem_5p_StopPos,$stem_5p_Seq,$stem_5p_Length,$stem_3p_StartPos,$stem_3p_StopPos,$stem_3p_Seq,$stem_3p_Length,$stem_isPK)=split/\t/;
	    my $c1 = $db->prepare("INSERT INTO Stem (stem_SubID,stem_5p_StartPos,stem_5p_StopPos,stem_5p_Seq,stem_5p_Length,stem_3p_StartPos,stem_3p_StopPos,stem_3p_Seq,stem_3p_Length,stem_isPK,stem_CreationDate,rna_ID) VALUES (?,?,?,?,?,?,?,?,?,?,NOW(),?)");
	    $c1->execute($stem_SubID,$stem_5p_StartPos,$stem_5p_StopPos,$stem_5p_Seq,$stem_5p_Length,$stem_3p_StartPos,$stem_3p_StopPos,$stem_3p_Seq,$stem_3p_Length,$stem_isPK,$rna_ID);
	    if($stem_isPK==1){
		my $pkID=$rna_ID ."_". $stem_SubID;
		my $c2 = $db->prepare("select max(stem_ID) from Stem");
		$c2->execute();
		my @row = $c2->fetchrow_array();
		$pkStems{$pkID}=$row[0];
	    }
	}
    }
    close FL;
    return \%pkStems;
}

### SEGMENT ###
sub loadSegmentTable {
    my($db)=@_;
    my $segmentFileName="allSegments.txt";
    open(FL,$segmentFileName) or die "Could not open $segmentFileName for reading \n";
    while(<FL>){
	chomp;
	unless(/^#/){
	    my($ran_id,$segment_SubID,$segment_NumBPs,$segment_5pStartPos,$segment_5pStopPos,$segment_5pSeq,$segment_5pLength,$segment_3pStartPos,$segment_3pStopPos,$segment_3pSeq,$segment_3pLength)=split/\t/;
	    my $c1 = $db->prepare("INSERT INTO Segment (segment_SubID,segment_NumBPs,segment_5pStartPos,segment_5pStopPos,segment_5pSeq,segment_5pLength,segment_3pStartPos,segment_3pStopPos,segment_3pSeq,segment_3pLength,segment_CreationDate,rna_ID) VALUES (?,?,?,?,?,?,?,?,?,?,NOW(),?)");
	    $c1->execute($segment_SubID,$segment_NumBPs,$segment_5pStartPos,$segment_5pStopPos,$segment_5pSeq,$segment_5pLength,$segment_3pStartPos,$segment_3pStopPos,$segment_3pSeq,$segment_3pLength,$ran_id);
	}
    }
    close FL;
}




########################
#### DEFAULT TABLES ####
########################
sub loadReferenceDatabaseTable {
    my($db)=@_;
    my $refDatabaseFileName="refDatabaseTableInfo.txt";
    open(FL,$refDatabaseFileName) or die "Could not open $refDatabaseFileName for reading\n";
    while(<FL>){
	chomp;
	my($refName,$refDesc,$refLink)=split/\t/;
	my $c1 = $db->prepare("INSERT INTO RefrenceDatabase (reference_Name,reference_Description,reference_Link,reference_CreationDate)VALUES (?,?,?,NOW())"); 
	$c1->execute($refName,$refDesc,$refLink);
    }
    close FL;
}

sub loadValidationTable {
    my($db)=@_;
    my $validationFileName="validationTableInfo.txt";
    open(FL,$validationFileName) or die "Could not open $validationFileName for reading\n";
    while(<FL>){
	chomp;
	my($validationName,$validationDesc)=split/\t/;
	my $c1 = $db->prepare("INSERT INTO Validation  (validation_Name,validation_Desc,validation_CreationDate) VALUES (?,?,NOW())"); 
	$c1->execute($validationName,$validationDesc);
    }
    close FL;
}

sub loadTypeTabel {
    my($db)=@_;
    my $typeFileName="rnaTypeTableIfo.txt";
    open(FL,$typeFileName) or die "Could not open $typeFileName for reading\n";  
    while(<FL>){
        chomp;
        my($typeName,$typeDesc)=split/\t/;
        my $c1 = $db->prepare("INSERT INTO RNAType (type_Name,type_Desc,type_CreationDate) VALUES (?,?,NOW())");
        $c1->execute($typeName,$typeDesc);
    }
    close FL;

}

sub loadMethodTable {
    my($db)=@_;
    my $methodInfoFileName="methodTableInfo.txt";
    open(FL,$methodInfoFileName) or die "Could not open $methodInfoFileName for reading\n";
    while(<FL>){
	chomp;
	my($methodName,$methodDesc)=split/\t/;
	my $c1 = $db->prepare("INSERT INTO Method (method_Name,method_Desc,method_CreationDate) VALUES (?,?,NOW())"); 
	$c1->execute($methodName,$methodDesc); 
    }
    close FL;
}


