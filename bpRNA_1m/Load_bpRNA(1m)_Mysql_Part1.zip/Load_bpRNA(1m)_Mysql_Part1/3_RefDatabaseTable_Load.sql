/******************** REFERENCE DATABASE TABLE ******************/
INSERT INTO RefrenceDatabase (reference_Name,reference_Description,reference_Link,reference_CreationDate)VALUES ('CRW','Comparative RNA Web Site(The Gutell Lab)','http://www.rna.ccbb.utexas.edu/',NOW());
INSERT INTO RefrenceDatabase (reference_Name,reference_Description,reference_Link,reference_CreationDate)VALUES ('tmRNA','tmRNA Database','http://rth.dk/resources/rnp/tmRDB/rna/tmrna.html',NOW());
INSERT INTO RefrenceDatabase (reference_Name,reference_Description,reference_Link,reference_CreationDate)VALUES ('SRP','SRP Database','http://rth.dk/resources/rnp/SRPDB/',NOW());
INSERT INTO RefrenceDatabase (reference_Name,reference_Description,reference_Link,reference_CreationDate)VALUES ('SPR','Sprinzl tRNA Database','http://trna.bioinf.uni-leipzig.de/DataOutput/Search',NOW());
INSERT INTO RefrenceDatabase (reference_Name,reference_Description,reference_Link,reference_CreationDate)VALUES ('RNP','RNase P Database','http://jwbrown.mbio.ncsu.edu/RNaseP/home.html',NOW());
INSERT INTO RefrenceDatabase (reference_Name,reference_Description,reference_Link,reference_CreationDate)VALUES ('RFAM','Rfam Database(12.2)','http://rfam.xfam.org/',NOW());
INSERT INTO RefrenceDatabase (reference_Name,reference_Description,reference_Link,reference_CreationDate)VALUES ('PDB','RCSB Protein Data Bank','http://www.rcsb.org/pdb/home/home.do',NOW());
