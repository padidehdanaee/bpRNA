/************************* METHOD TABLE *************************/
INSERT INTO Method (method_Name,method_Desc,method_CreationDate) VALUES ('COMPARATIVE SEQUENCE ANALYSIS','NA',NOW());
INSERT INTO Method (method_Name,method_Desc,method_CreationDate) VALUES ('ELECTRON MICROSCOPY','NA',NOW());
INSERT INTO Method (method_Name,method_Desc,method_CreationDate) VALUES ('FLUORESCENCE TRANSFER','NA',NOW());
INSERT INTO Method (method_Name,method_Desc,method_CreationDate) VALUES ('SOLID-STATE NMR','NA',NOW());
INSERT INTO Method (method_Name,method_Desc,method_CreationDate) VALUES ('SOLUTION NMR','NA',NOW());
INSERT INTO Method (method_Name,method_Desc,method_CreationDate) VALUES ('SOLUTION SCATTERING, SOLUTION NMR','NA',NOW());
INSERT INTO Method (method_Name,method_Desc,method_CreationDate) VALUES ('X-RAY DIFFRACTION','NA',NOW());
